-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2023 at 07:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jcrud`
--

-- --------------------------------------------------------

--
-- Table structure for table `stud`
--

CREATE TABLE `stud` (
  `ID` int(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `age` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `course` varchar(200) NOT NULL,
  `year` varchar(100) NOT NULL,
  `section` varchar(200) NOT NULL,
  `pf` double NOT NULL,
  `net` double NOT NULL,
  `im` double NOT NULL,
  `ms` double NOT NULL,
  `avg` double NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stud`
--

INSERT INTO `stud` (`ID`, `name`, `age`, `gender`, `course`, `year`, `section`, `pf`, `net`, `im`, `ms`, `avg`, `status`) VALUES
(1, 'KIRKLAND', '23', 'MALE', 'BSIS', '2', 'B', 78, 89, 76, 76, 79.75, 'Passed'),
(2, 'GINNY FRIEND', '23', 'FEMALE', 'BSCE', '4', 'B', 87, 85, 60, 60, 73, 'Failed'),
(4, 'RON MATTHEW LINGAD', '26', 'MALE', 'BSIT', '2', 'A', 100, 74, 72, 72, 79.5, 'Passed'),
(5, 'JOHN MATTHEW BERG', '21', 'MALE', 'BSCE', '1', 'D', 56, 90, 85, 85, 79, 'Passed'),
(6, 'ANGELA SHARP', '18', 'FEMALE', 'BSIS', '1', 'B', 90, 75, 78, 78, 80.25, 'Passed'),
(9, 'DANIEL WOODES', '23', 'MALE', 'BSIT', '3', 'A', 89, 97.6, 89, 89, 91.15, 'Passed'),
(10, 'EDWARD KENWAY', '27', 'MALE', 'BSIS', '4', 'C', 87, 56, 70, 70, 70.75, 'Failed'),
(17, 'HINA YU', '20', 'FEMALE', 'BSCE', '2', 'B', 89, 87, 85, 85, 86.5, 'Passed'),
(18, 'OLIVER LEVASSAUR', '24', 'MALE', 'BSCE', '3', 'D', 78, 81, 82, 82, 80.75, 'Passed'),
(19, 'ANNE BONEY', '22', 'FEMALE', 'BSIS', '2', 'C', 87, 78, 95, 95, 88.75, 'Passed'),
(20, 'CHUNSIK ', '19', 'FEMALE', 'BSCE', '1', 'B', 67, 78, 77, 77, 74.75, 'Failed'),
(22, 'JHAY VINZON', '20', 'MALE', 'BSCE', '2', 'D', 78, 87, 99, 99, 90.75, 'Passed'),
(23, 'EMMA JONES', '19', 'FEMALE', 'BSIS', '4', 'C', 78, 87, 67, 67, 74.75, 'Failed');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stud`
--
ALTER TABLE `stud`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stud`
--
ALTER TABLE `stud`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
